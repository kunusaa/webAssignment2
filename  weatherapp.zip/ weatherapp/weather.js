const container = document.querySelector('.container');
const search = document.querySelector('.search-box button');
const weatherBox = document.querySelector('.weather-box');
const weatherDetails = document.querySelector('.weather-details');
const error404 = document.querySelector('.not-found');
const countryCodeElement = document.querySelector('.country-code');
const maxWords = 250;

let marker;

search.addEventListener('click', async () => {
    const APIKey = '20a2cc05a0e3e06f1fff99281c82a7b4';
    const cityInput = document.querySelector('.search-box input');
    const city = cityInput.value;

    if (city === '') 
        return;

    try {
        const geocodingResponse = await fetch(`https://api.mapbox.com/geocoding/v5/mapbox.places/${city}.json?access_token=${mapboxgl.accessToken}`);

        if (!geocodingResponse.ok) {
            console.error('Ошибка при выполнении запроса геокодинга');
            return;
        }

        const geocodingData = await geocodingResponse.json();

        const firstFeature = geocodingData.features?.[0];

        if (!firstFeature?.place_name || !firstFeature?.center) {
            handleCityNotFound();
            return;
        }

        const [longitude, latitude] = firstFeature.center;

        map.setCenter([longitude, latitude + 0.02]);

        if (marker) {
            marker.setLngLat([longitude, latitude]);
        } else {
            marker = new mapboxgl.Marker({ color: 'red' }).setLngLat([longitude, latitude]).addTo(map);
        }

        const weatherData = await fetchWeatherData(latitude, longitude, APIKey);
        console.log('Fetched Weather Data:', weatherData); // Add this line to log the weather data

        if (!weatherData) {
            handleCityNotFound();
            return;
        }
        updateWeatherUI(weatherData);
        error404.classList.remove('active');

        const wikipediaData = await fetchWikipediaData(city);
        const maxWords = 250;
        updateWikipediaUI(wikipediaData, maxWords);
        
    } catch (error) {
        console.error('Произошла ошибка:', error);
        // Обработка ошибки, например, отображение сообщения об ошибке пользователю
    }
});

function handleCityNotFound() {
    container.style.height = '400px';
    weatherBox.classList.remove('active');
    weatherDetails.classList.remove('active');
    error404.classList.add('active');
}

async function fetchWeatherData(latitude, longitude, apiKey) {
    const weatherResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=metric&appid=${apiKey}`);
    
    if (!weatherResponse.ok) {
        console.error('Ошибка при выполнении запроса на погоду');
        return null;
    }

    const weatherData = await weatherResponse.json();
    console.log('Weather Data:', weatherData); // Add this line to log the weather data
    return weatherData;
}

function updateWeatherUI(weatherData) {
    container.style.height = '600px';
    weatherBox.classList.add('active');
    weatherDetails.classList.add('active');

    const image = document.querySelector('.weather-box img');
    const temperature = document.querySelector('.weather-box .temperature');
    const description = document.querySelector('.weather-box .description');
    const humidity = document.querySelector('.weather-details .humidity span');
    const wind = document.querySelector('.weather-details .wind span');
    const feels = document.querySelector('.weather-details .feels span');
    const pressure = document.querySelector('.weather-details .pressure span');
    const rainVolume = document.querySelector('.weather-details .rain-volume-value');

    switch (weatherData.weather[0].main) {
        case "Clear":
            image.src = 'img/clear.png';
            break;
        case "Rain":
            image.src = 'img/rain.png';
            break;
        case "Snow":
            image.src = 'img/snow.png';
            break;
        case "Clouds":
            image.src = 'img/cloud.png';
            break;
        case "Mist":
        case "Haze":
            image.src = 'img/mist.png';
            break;
        default:
            image.src = 'img/cloud.png';
    }

    temperature.innerHTML = `${Math.round(weatherData.main.temp)}<span>°C</span>`;
    description.innerHTML = `${weatherData.weather[0].description}`;
    humidity.innerHTML = `${weatherData.main.humidity} %`;
    wind.innerHTML = `${Math.round(weatherData.wind.speed)} Km/h`;
    feels.innerHTML = `${Math.round(weatherData.main.feels_like)}<span>°C</span>`;
    pressure.innerHTML = `${weatherData.main.pressure} hPa`;
    countryCodeElement.innerText = weatherData.sys.country;

    if (weatherData.rain && weatherData.rain['3h']) {
        const rainValue = weatherData.rain['3h'];
        console.log(`${rainValue} mm`);
        rainVolume.innerText = rainValue.toFixed(2);
    } else {
        console.log('');
        rainVolume.innerText = '0.00';
    }
}

async function fetchWikipediaData(cityName) {
    const wikipediaEndpoint = `https://en.wikipedia.org/w/api.php?action=query&format=json&prop=extracts&exintro=true&redirects=true&titles=${cityName}&origin=*`;

    try {
        const wikipediaResponse = await fetch(wikipediaEndpoint);

        if (!wikipediaResponse.ok) {
            throw new Error('Ошибка при выполнении запроса к API Wikipedia');
        }

        const wikipediaData = await wikipediaResponse.json();

        const pages = wikipediaData.query.pages;
        const firstPageId = Object.keys(pages)[0];
        const extract = pages[firstPageId].extract;

        const plainText = extract.replace(/<[^>]+>/g, '').trim();

        return plainText;
    } catch (error) {
        console.error('Произошла ошибка при получении данных из Wikipedia API:', error);
        throw error; // Перебрасываем ошибку
    }
}

function truncateText(text, maxWords) {
    const wordArray = text.split(/\s+/);
    const truncatedArray = wordArray.slice(0, maxWords);
    const truncatedText = truncatedArray.join(' ');

    if (wordArray.length > maxWords) {
        return truncatedText + '...';
    } else {
        return truncatedText;
    }
}


function updateWikipediaUI(wikipediaData, maxWords) {
    const wikipediaInfo = document.getElementById('wikipedia-info');

    if (wikipediaData) {
        // Remove HTML tags and extra spaces
        const plainText = wikipediaData.replace(/<[^>]+>/g, '').trim();

        // Truncate text to the specified number of words
        const truncatedText = truncateText(plainText, maxWords);

        wikipediaInfo.innerHTML = truncatedText + '...';
        document.querySelector('.wikipedia-info').classList.add('active');
    } else {
        wikipediaInfo.innerText = '';
        document.querySelector('.wikipedia-info').classList.remove('active');
    }
}

